# -*- coding: utf-8 -*-
"""Setup the turbogears-tw2-tutorial application"""

import logging
from tg import config
from myapp import model

import transaction


def bootstrap(command, conf, vars):
    """Place any commands to setup myapp here"""

    for name in ['Action', 'Comedy', 'Romance', 'Sci-fi']:
        model.DBSession.add(model.Genre(name=name))
    transaction.commit()

    # <websetup.bootstrap.before.auth

    # <websetup.bootstrap.after.auth>
