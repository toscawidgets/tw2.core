# -*- coding: utf-8 -*-
"""Test suite for the TG app's models"""
from nose.tools import eq_

from myapp import model
from myapp.tests.models import ModelTest

